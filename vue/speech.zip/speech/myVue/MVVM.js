class MVVM{
    constructor(options){
       // 一开始 先把可用的东西挂载在实例上 方便
        this.$el=options.el;
        this.$data=options.data;

        // let computed=options.computed;
        // let methods=options.methods;
        //如果有要编译的的模板据就开始模板
        if(this.$el){

        //    数据劫持 就是对象的所有属性 改成get和set方法
        //     new Observer(this.$data);
            new Observer(this.$data);
          /*  for(let key in computed){
                Object.defineProperty(this.$data,key,{//有依赖关系
                    get:()=>{
                        return computed[key].call(this);
                    }
                })
            }
*/
           /* for(let key in methods){
                Object.defineProperty(this,key,{//有依赖关系
                    get:()=>{
                        return methods[key];
                    }
                })
            }*/
            //    代理数据
            // this.proxyData(this.$data);
        //    用数据和元素进行编译
            new Compile(this.$el,this);
        }
    }
    proxyData(data){
        Object.keys(data).forEach(key=>{
            Object.defineProperty(this,key,{
                get(){
                    return data[key];
                },
                set(newValue){
                   data[key]=newValue;
                }
            })
        })

    }
}